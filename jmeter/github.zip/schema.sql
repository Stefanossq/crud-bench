CREATE TABLE IF NOT EXISTS clientes (
    id            BIGSERIAL PRIMARY KEY,
    nome          VARCHAR(150) NOT NULL,
    email         VARCHAR(150) NOT NULL UNIQUE,
    telefone      VARCHAR(30),
    cidade        VARCHAR(100),
    estado        CHAR(2),
    data_cadastro TIMESTAMP NOT NULL DEFAULT now()
);
