-- Rode ANTES de cada execucao do JMeter para manter o dataset em 50k (ou 20k)
-- 1) limpar e reiniciar ids
TRUNCATE TABLE clientes RESTART IDENTITY;
-- 2) recarregar o dataset (ajuste o nome do arquivo gerado pelo seu script Faker)
--    docker exec -i crudbench-postgres psql -U admin -d crudbench < dataset_50k.sql
-- 3) conferir
SELECT count(*) FROM clientes;
