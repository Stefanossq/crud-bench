# Avaliação de Desempenho de uma Aplicação CRUD

API REST de cadastro de clientes (Spring Boot + PostgreSQL) avaliada com Apache JMeter
em três cenários de leitura/escrita, com 100 clientes simultâneos.

**Autor:** Stefano Camargo Squarcieri — UFSM · **Vídeo:** _(cole aqui o link do YouTube não listado)_ · **Relatório:** [PDF](docs/relatorio.pdf)

## Arquitetura

```
JMeter (100 threads) ──HTTP/JSON──▶ API Spring Boot :8080 ──HikariCP (50)──▶ PostgreSQL 16 (Docker)
Swagger UI (demo)    ──────────────▶        └─ Controller → Service → Repository → JPA
```

O PostgreSQL roda em container Docker; a API e o JMeter rodam no host.

| Componente | Tecnologia |
|---|---|
| Linguagem | Java 17 |
| Framework | Spring Boot 3.2.5 (Web, Data JPA, Validation, Actuator) |
| Banco | PostgreSQL 16 |
| Pool | HikariCP, 50 conexões |
| Carga | Apache JMeter 5.6.3 (modo headless) |
| Documentação | Swagger UI (springdoc 2.5.0) |
| Dataset | Python Faker (pt_BR), 50.000 registros |

## Endpoints

| ID | Operação | Endpoint |
|---|---|---|
| RF01 | Criar | `POST /api/clientes` |
| RF02 | Buscar por ID | `GET /api/clientes/{id}` |
| RF03 | Listar (paginado) | `GET /api/clientes?page=&size=` |
| RF04 | Atualizar | `PUT /api/clientes/{id}` |
| RF05 | Remover | `DELETE /api/clientes/{id}` |
| RF06 | Buscar por nome | `GET /api/clientes/search?q=` |

Swagger UI: http://localhost:8080/swagger-ui.html · Saúde: http://localhost:8080/actuator/health

## Como reproduzir

```bash
# 1. Banco (cria a tabela automaticamente)
docker compose up -d

# 2. Dataset (50k registros gerados com Faker)
docker exec -i crudbench-postgres psql -U admin -d crudbench < dataset_50k.sql

# 3. API
mvn spring-boot:run

# 4. Cenário (exemplo: A), modo headless
jmeter -n -t jmeter/cenario_A.jmx -l results/A.jtl -e -o results/A_html

# 5. Antes de CADA execução, restaure o dataset
#    (veja sql/reset.sql)

# Índices
docker exec -i crudbench-postgres psql -U admin -d crudbench < sql/indexes_btree.sql
```

## Cenários (100 clientes, 60 s, ramp-up 10 s)

| Cenário | Leituras | Escritas | Distribuição |
|---|---|---|---|
| A | 50% | 50% | 50 leitores + 50 escritores |
| B | 75% | 25% | 75 leitores + 25 escritores |
| C | 25% | 75% | 25 leitores + 75 escritores |

Leitores fazem `GET` e escritores fazem `POST`.

## Resultados

### 50.000 registros

| Cenário | Índice | Throughput (req/s) | Média (ms) | Máx (ms) | Erros |
|---|---|---|---|---|---|
| A 50/50 | sem | 3.363 | 27 | 204 | 0% |
| B 75/25 | sem | 3.757 | 24 | 420 | 0% |
| C 25/75 | sem | 3.069 | 29 | 172 | 0% |
| A 50/50 | com | 3.045 | 28 | 318 | 0% |
| B 75/25 | com | 3.726 | 24 | 198 | 0% |
| C 25/75 | com | 2.873 | 30 | 294 | 0% |

### 20.000 registros (com índices)

| Cenário | Throughput (req/s) | Média (ms) | Erros |
|---|---|---|---|
| A 50/50 | 3.253 | 28 | 0% |
| B 75/25 | 3.773 | 24 | 0% |
| C 25/75 | 2.472 | 35 | 0% |

## Análise (respostas às perguntas do enunciado)

**1. Reduzir o dataset para 20k?** Com leituras por chave primária (B-tree, O(log n)) o impacto é pequeno:
+6,8% (A), +1,3% (B) e −13,9% (C). A queda em C é atribuída a ruído (maior concorrência de escritas, execução única).

**2. Adicionar índices?** Índices B-tree em `nome`, `email` e `cidade` **não melhoraram** o desempenho (−9,5% em A, −0,8% em B, −6,4% em C),
pois o workload lê por PK e cada `INSERT` precisa atualizar todos os índices. Índice só ajuda quando a consulta usa a coluna indexada.

**3. Qual índice escolher?** Para o `GET /search?q=`, o candidato é `nome`. Como a consulta é `lower(nome) LIKE lower('%q%')`, um B-tree comum
não é usado; o adequado é um índice GIN com `pg_trgm` sobre `lower(nome)` (`sql/indexes_trgm.sql`). `email` já tem índice por ser UNIQUE e
`cidade` tem baixa seletividade.

**4. SQL vs NoSQL?** PostgreSQL: esquema fixo, ACID forte, JOINs e transações; custo por transação nas escritas.
MongoDB: documentos JSON, consistência configurável (write concern), escalabilidade horizontal. Para o domínio de clientes ambos atendem;
a escolha depende de consistência e padrão de acesso. _(Comparação teórica, sem medição empírica.)_

## Limitações

1. As leituras do workload são por chave primária; os índices adicionais não são exercitados.
2. Cada cenário foi executado uma única vez, sem intervalo de confiança.
3. O cenário C é instável (ruído nas escritas, principalmente na comparação 50k vs 20k).
4. Os `POST` aumentam o dataset durante cada execução de 60 s.
5. A comparação SQL vs NoSQL é teórica.

## Trabalhos futuros

- Incluir `/search` no workload e comparar com e sem índice GIN (`EXPLAIN ANALYZE`).
- Várias rodadas por cenário com média e desvio padrão; reportar p95/p99.
- Versão da API com MongoDB para comparação direta.
