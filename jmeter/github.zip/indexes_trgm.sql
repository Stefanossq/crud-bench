-- Indice adequado para o endpoint /search (LIKE '%texto%' com lower())
-- O Hibernate gera: lower(nome) like lower('%q%')
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE INDEX IF NOT EXISTS idx_clientes_nome_trgm
    ON clientes USING gin (lower(nome) gin_trgm_ops);

-- Para demonstrar no video (compare antes e depois do indice):
-- EXPLAIN ANALYZE SELECT * FROM clientes WHERE lower(nome) LIKE lower('%silva%');
