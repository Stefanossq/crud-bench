-- Indices usados nos experimentos (B-tree simples)
-- Obs.: email ja possui indice por ser UNIQUE; este e redundante.
CREATE INDEX IF NOT EXISTS idx_clientes_nome   ON clientes (nome);
CREATE INDEX IF NOT EXISTS idx_clientes_email  ON clientes (email);
CREATE INDEX IF NOT EXISTS idx_clientes_cidade ON clientes (cidade);
